import UIKit
import WebKit
import Toast // 確保導入 Toast-Swift

class StartViewController: UIViewController, WKNavigationDelegate {
    private let webView = WKWebView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Starting viewDidLoad")
        setupUI()
        print("Finished setupUI")
        loadServerAddress()
        print("Finished loadServerAddress")
        configureNavigationBar()
        print("Finished configureNavigationBar")
        webView.navigationDelegate = self
        print("Finished viewDidLoad")
    }
    
    private func setupUI() {
        view.backgroundColor = .white
        
        // Setup WebView
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        
        // Auto Layout Constraints
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }
    
    private func loadServerAddress() {
        let defaultAddress = "http://xinyuan.6.ibiz.tw/supplier/"
        if let savedAddress = UserDefaults.standard.string(forKey: "ServerAddress"),
           let url = URL(string: savedAddress), UIApplication.shared.canOpenURL(url) {
            print("savedAddress: \(savedAddress)")
            let request = URLRequest(url: url)
            webView.load(request)
        } else if let url = URL(string: defaultAddress), UIApplication.shared.canOpenURL(url) {
            print("defaultAddress: \(defaultAddress)")
            let request = URLRequest(url: url)
            webView.load(request)
        } else {
            print("Invalid server address")
            view.makeToast("Invalid server address", duration: 3.0, position: .bottom)
        }
    }
    
    private func configureNavigationBar() {
        let shouldShowNavBar = UserDefaults.standard.object(forKey: "ShowNavigationBar") as? Bool ?? true
        navigationController?.setNavigationBarHidden(!shouldShowNavBar, animated: false)
        // Set navigation bar title to "樹桔子"
        navigationItem.title = "樹桔子"
    }
    
    // MARK: - WKNavigationDelegate
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // 當網頁載入完成時顯示 Toast
        if let currentURL = webView.url?.absoluteString {
             view.makeToast(currentURL, duration: 3.0, position: .bottom)
        }
    }
}
