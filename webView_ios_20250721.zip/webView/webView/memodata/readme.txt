新增設定，蘋果電腦，支持推播
<key>com.apple.developer.aps-push-notification</key>
<true/>
