import UIKit
import UserNotifications

class ConfigViewController: UIViewController {
    private let urlTextField = UITextField()
    private let startButton = UIButton(type: .system)
    private let navigationBarSwitch = UISegmentedControl(items: [NSLocalizedString("Show", comment: ""), NSLocalizedString("Hide", comment: "")])
    private let tokenTextView = UITextView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadServerAddress()
        loadNavigationBarSetting()
        requestNotificationPermission()
        // 監聽 token 更新通知
        NotificationCenter.default.addObserver(self, selector: #selector(updateTokenDisplay(_:)), name: .didReceiveDeviceToken, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func setupUI() {
        title = NSLocalizedString("Server Settings", comment: "")
        view.backgroundColor = .white
        
        let urlLabel = UILabel()
        urlLabel.text = NSLocalizedString("Server URL", comment: "")
        urlLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(urlLabel)
        
        urlTextField.placeholder = NSLocalizedString("Enter URL", comment: "")
        urlTextField.borderStyle = .roundedRect
        urlTextField.delegate = self
        urlTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(urlTextField)
        
        let navigationLabel = UILabel()
        navigationLabel.text = NSLocalizedString("Show Navigation Bar", comment: "")
        navigationLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(navigationLabel)
        
        navigationBarSwitch.selectedSegmentIndex = 0
        navigationBarSwitch.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(navigationBarSwitch)
        
        startButton.setTitle(NSLocalizedString("Start", comment: ""), for: .normal)
        startButton.addTarget(self, action: #selector(startButtonTapped), for: .touchUpInside)
        startButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(startButton)
        
        tokenTextView.isEditable = false
        tokenTextView.isScrollEnabled = true
        tokenTextView.font = .systemFont(ofSize: 14)
        tokenTextView.text = NSLocalizedString("Waiting for push token...", comment: "")
        tokenTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tokenTextView)
        
        NSLayoutConstraint.activate([
            urlLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            urlLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            
            urlTextField.topAnchor.constraint(equalTo: urlLabel.bottomAnchor, constant: 10),
            urlTextField.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            urlTextField.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            urlTextField.heightAnchor.constraint(equalToConstant: 40),
            
            navigationLabel.topAnchor.constraint(equalTo: urlTextField.bottomAnchor, constant: 20),
            navigationLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            
            navigationBarSwitch.topAnchor.constraint(equalTo: navigationLabel.bottomAnchor, constant: 10),
            navigationBarSwitch.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            navigationBarSwitch.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            navigationBarSwitch.heightAnchor.constraint(equalToConstant: 40),
            
            startButton.topAnchor.constraint(equalTo: navigationBarSwitch.bottomAnchor, constant: 20),
            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            startButton.widthAnchor.constraint(equalToConstant: 100),
            startButton.heightAnchor.constraint(equalToConstant: 44),
            
            tokenTextView.topAnchor.constraint(equalTo: startButton.bottomAnchor, constant: 20),
            tokenTextView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            tokenTextView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            tokenTextView.heightAnchor.constraint(equalToConstant: 200)
        ])
    }
    
    private func loadServerAddress() {
        let defaultAddress = "http://xinyuan.6.ibiz.tw/supplier/"
        let savedAddress = UserDefaults.standard.string(forKey: "ServerAddress") ?? defaultAddress
        urlTextField.text = savedAddress
    }
    
    private func loadNavigationBarSetting() {
        let showNavigationBar = UserDefaults.standard.bool(forKey: "ShowNavigationBar")
        navigationBarSwitch.selectedSegmentIndex = showNavigationBar ? 0 : 1
    }
    
    private func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            DispatchQueue.main.async {
                if let error = error {
                    self.tokenTextView.text = NSLocalizedString("Notification permission request failed: \(error.localizedDescription)", comment: "")
                    self.showToast(message: NSLocalizedString("Failed to request notification permission", comment: ""))
                    return
                }
                if granted {
                    UIApplication.shared.registerForRemoteNotifications()
                } else {
                    self.tokenTextView.text = NSLocalizedString("Notifications not authorized", comment: "")
                    self.showToast(message: NSLocalizedString("Please enable notifications in Settings", comment: ""))
                }
            }
        }
    }
    
    @objc private func updateTokenDisplay(_ notification: Notification) {
        if let token = notification.userInfo?["deviceToken"] as? String {
            tokenTextView.text = NSLocalizedString("Token: \(token)", comment: "")
            sendTokenToServer(token: token)
        } else {
            tokenTextView.text = NSLocalizedString("Failed to retrieve push token", comment: "")
        }
    }
    
    private func sendTokenToServer(token: String) {
        guard let serverAddress = urlTextField.text, !serverAddress.isEmpty, serverAddress.isValidURL else {
            tokenTextView.text = NSLocalizedString("Invalid server URL", comment: "")
            showToast(message: NSLocalizedString("Please enter a valid URL", comment: ""))
            return
        }
        
        // Extract the root URL (scheme + host)
        guard let url = URL(string: serverAddress),
              let rootURL = URL(string: "\(url.scheme ?? "http")://\(url.host ?? "")") else {
            tokenTextView.text = NSLocalizedString("Invalid URL format", comment: "")
            showToast(message: NSLocalizedString("Invalid URL format", comment: ""))
            return
        }
        
        let urlString = "\(rootURL.absoluteString)/app/api/?mode=token&xid=&device=ios&token=\(token)&language=tw"
        print(urlString)
        
        guard let url = URL(string: urlString) else {
            
            tokenTextView.text = NSLocalizedString("Invalid URL format", comment: "")
            showToast(message: NSLocalizedString("Invalid URL format", comment: ""))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    self.tokenTextView.text = NSLocalizedString("Token: \(token)\nURL: \(urlString)\nError: \(error.localizedDescription)", comment: "")
                    self.showToast(message: NSLocalizedString("Failed to send token: \(error.localizedDescription)", comment: ""))
                    return
                }
                
                if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                    var responseText = NSLocalizedString("Token: \(token)\nURL: \(urlString)\nStatus: Success", comment: "")
                    if let data = data, let rawResponse = String(data: data, encoding: .utf8) {
                        responseText += NSLocalizedString("\nRaw Response: \(rawResponse)", comment: "")
                    }
                    self.tokenTextView.text = responseText
                    self.showToast(message: NSLocalizedString("Token sent successfully", comment: ""))
                } else {
                    var responseText = NSLocalizedString("Token: \(token)\nURL: \(urlString)\nStatus: Failed", comment: "")
                    if let data = data, let rawResponse = String(data: data, encoding: .utf8) {
                        responseText += NSLocalizedString("\nRaw Response: \(rawResponse)", comment: "")
                    }
                    self.tokenTextView.text = responseText
                    self.showToast(message: NSLocalizedString("Failed to send token", comment: ""))
                }
            }
        }
        task.resume()
    }
    
    private func showToast(message: String) {
        let toastLabel = UILabel()
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = .white
        toastLabel.textAlignment = .center
        toastLabel.font = .systemFont(ofSize: 12)
        toastLabel.text = message
        toastLabel.numberOfLines = 0
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10
        toastLabel.clipsToBounds = true
        toastLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toastLabel)
        
        NSLayoutConstraint.activate([
            toastLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            toastLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            toastLabel.widthAnchor.constraint(lessThanOrEqualToConstant: 300),
            toastLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 35)
        ])
        
        UIView.animate(withDuration: 3.0, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: { _ in
            toastLabel.removeFromSuperview()
        })
    }
    
    @objc private func startButtonTapped() {
        guard let url = urlTextField.text, !url.isEmpty, url.isValidURL else {
            showToast(message: NSLocalizedString("Please enter a valid URL", comment: ""))
            return
        }
        
        UserDefaults.standard.set(url, forKey: "ServerAddress")
        let showNavigationBar = navigationBarSwitch.selectedSegmentIndex == 0
        UserDefaults.standard.set(showNavigationBar, forKey: "ShowNavigationBar")
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            let startVC = StartViewController()
            self.navigationController?.pushViewController(startVC, animated: true)
        }
    }
}

// MARK: - UITextFieldDelegate
extension ConfigViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

// MARK: - URL Validation
extension String {
    var isValidURL: Bool {
        guard let url = URL(string: self) else { return false }
        return UIApplication.shared.canOpenURL(url)
    }
}

// MARK: - Notification Name
extension Notification.Name {
    static let didReceiveDeviceToken = Notification.Name("DidReceiveDeviceToken")
}

