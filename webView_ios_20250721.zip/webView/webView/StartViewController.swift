import UIKit
import WebKit
import Toast

class StartViewController: UIViewController, WKNavigationDelegate {
    private let webView = WKWebView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Starting viewDidLoad")
        setupUI()
        print("Finished setupUI")
        loadServerAddress()
        print("Finished loadServerAddress")
        configureNavigationBar()
        print("Finished configureNavigationBar")
        webView.navigationDelegate = self
        print("Finished viewDidLoad")
    }
    
    private func setupUI() {
        view.backgroundColor = .white
        
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }
    
    private func loadServerAddress() {
        let defaultAddress = "http://xinyuan.6.ibiz.tw/supplier/"
        if let savedAddress = UserDefaults.standard.string(forKey: "ServerAddress"),
           let url = URL(string: savedAddress), url.scheme != nil, url.host != nil {
            print("Loading savedAddress: \(savedAddress)")
            let request = URLRequest(url: url)
            webView.load(request)
        } else if let url = URL(string: defaultAddress), url.scheme != nil, url.host != nil {
            print("Loading defaultAddress: \(defaultAddress)")
            let request = URLRequest(url: url)
            webView.load(request)
        } else {
            print("Invalid server address")
            view.makeToast("Invalid server address", duration: 3.0, position: .bottom)
        }
    }
    
    private func configureNavigationBar() {
        let shouldShowNavBar = UserDefaults.standard.bool(forKey: "ShowNavigationBar")
        navigationController?.setNavigationBarHidden(!shouldShowNavBar, animated: false)
        navigationItem.title = "樹桔子"
    }
    
    // MARK: - WKNavigationDelegate
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let currentURL = webView.url?.absoluteString {
            view.makeToast(currentURL, duration: 3.0, position: .bottom)
        }
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("WebView failed to load: \(error.localizedDescription)")
        view.makeToast("Failed to load webpage: \(error.localizedDescription)", duration: 3.0, position: .bottom)
    }
}
